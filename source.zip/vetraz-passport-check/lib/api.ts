// Set this to the verified /exec URL of the owner's deployed Apps Script.
const endpoint='https://script.google.com/macros/s/AKfycbzfWPeenba22UawAQDl3XdjRyiWmv7lYxpVB1fl3_zPhzJe2ea_UNWeBVQB3xmfw79-AA/exec';
const channel='vetraz-google-v1';
let ready:Promise<void>|undefined;
let frame:HTMLIFrameElement|undefined;
let peer:MessageEventSource|null=null;
let peerOrigin='';
let sequence=0;
let nonce='';
const pending=new Map<string,{resolve:(r:{status:number;data:unknown})=>void;reject:(e:Error)=>void;timer:ReturnType<typeof setTimeout>}>();

function googleOrigin(origin:string){return origin==='https://script.googleusercontent.com'||/^https:\/\/[a-z0-9-]+-script\.googleusercontent\.com$/.test(origin);}
function connect(){
  if(ready)return ready;
  if(!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(endpoint))return Promise.reject(new Error('Подключение Google ещё не опубликовано.'));
  nonce=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
  ready=new Promise<void>((resolve,reject)=>{
    frame=document.createElement('iframe');frame.hidden=true;frame.title='Подключение к общей базе';frame.referrerPolicy='no-referrer';
    let connected=false;
    const timer=setTimeout(()=>{
      if(connected)return;
      window.removeEventListener('message',receive);frame?.remove();frame=undefined;ready=undefined;peer=null;peerOrigin='';
      reject(new TypeError('Не удалось подключиться к базе Google.'));
    },45000);
    const receive=(event:MessageEvent)=>{
      const m=event.data;
      if(!googleOrigin(event.origin)||!m||m.channel!==channel||m.nonce!==nonce)return;
      if(m.type==='ready'){
        if(!event.source || (peer && event.source!==peer))return;
        peer=event.source;peerOrigin=event.origin;connected=true;clearTimeout(timer);resolve();return;
      }
      if(event.source!==peer||event.origin!==peerOrigin||m.type!=='response'||typeof m.id!=='string')return;
      const call=pending.get(m.id);if(!call)return;
      clearTimeout(call.timer);pending.delete(m.id);
      if(typeof m.status!=='number'){call.reject(new Error('Неверный ответ базы.'));return;}
      call.resolve({status:m.status,data:m.data});
    };
    window.addEventListener('message',receive);
    const url=new URL(endpoint);url.searchParams.set('channel',nonce);frame.src=url.href;document.body.append(frame);
  });
  return ready;
}

async function iframeApi(accessKey:string,payload:Record<string,unknown>){
  await connect();
  const result=await new Promise<{status:number;data:unknown}>((resolve,reject)=>{
    const id=String(++sequence);
    const timer=setTimeout(()=>{pending.delete(id);reject(new TypeError('База Google не ответила. Повторите попытку.'));},45000);
    pending.set(id,{resolve,reject,timer});
    if(peer && 'postMessage' in peer)(peer as Window).postMessage({channel,nonce,type:'request',id,accessKey,payload},peerOrigin);
    else {clearTimeout(timer);pending.delete(id);reject(new TypeError('Подключение к базе прервано.'));}
  });
  return {ok:result.status>=200&&result.status<300,status:result.status,json:async()=>result.data};
}

// Direct requests deliberately omit browser credentials so Google account
// sessions on the device cannot select the account used for the request.
let transport:'direct'|'frame'|undefined;
async function directApi(accessKey:string,payload:Record<string,unknown>){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),payload.action==='read'?20000:45000);
  try{
    const response=await fetch(endpoint,{method:'POST',mode:'cors',credentials:'omit',redirect:'follow',cache:'no-store',referrerPolicy:'no-referrer',headers:{'Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify({accessKey,payload}),signal:controller.signal});
    const result=await response.json() as {status:number;data:unknown};
    if(!response.ok || !result || !Number.isInteger(result.status) || result.status<100 || result.status>599 || !result.data || typeof result.data!=='object')throw Error('Неверный ответ подключения Google.');
    return {ok:result.status>=200&&result.status<300,status:result.status,json:async()=>result.data};
  }catch(error){
    if(payload.action!=='read')throw Error('Не удалось подтвердить сохранение. Обновите список и проверьте сведения перед повторной правкой.');
    throw error;
  }finally{clearTimeout(timer);}
}
export async function api(accessKey:string,payload:Record<string,unknown>){
  if(transport==='frame')return iframeApi(accessKey,payload);
  if(transport==='direct')return directApi(accessKey,payload);
  // Select the connection with a read only. A failed write is never replayed
  // through a second connection: the server might already have saved it.
  if(payload.action!=='read')throw Error('Сначала обновите список.');
  try{const response=await directApi(accessKey,payload);transport='direct';return response;}
  catch{const response=await iframeApi(accessKey,payload);transport='frame';return response;}
}

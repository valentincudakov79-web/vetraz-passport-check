const origin='https://vetraz-passport-check.valentincudakov79.chatgpt.site';
const channel='vetraz-passports-v1';
let frame:HTMLIFrameElement|undefined;
let ready:Promise<void>|undefined;
let sequence=0;
const pending=new Map<string,{resolve:(r:{status:number;data:unknown})=>void;reject:(e:Error)=>void;timer:ReturnType<typeof setTimeout>}>();

function connect(){
  if(ready)return ready;
  ready=new Promise<void>((resolve,reject)=>{
    frame=document.createElement('iframe');
    frame.hidden=true;
    frame.title='Подключение к общей базе';
    frame.referrerPolicy='no-referrer';
    let connected=false;
    const timer=setTimeout(()=>{
      if(connected)return;
      window.removeEventListener('message',receive);
      frame?.remove();frame=undefined;ready=undefined;
      reject(new TypeError('Не удалось подключиться к общей базе.'));
    },25000);
    const receive=(event:MessageEvent)=>{
      if(event.origin!==origin||event.source!==frame?.contentWindow)return;
      const m=event.data;
      if(!m||m.channel!==channel)return;
      if(m.type==='ready'){connected=true;clearTimeout(timer);resolve();return;}
      if(m.type==='response'&&typeof m.id==='string'){
        const call=pending.get(m.id);if(!call)return;
        clearTimeout(call.timer);pending.delete(m.id);
        if(typeof m.status!=='number'){call.reject(new Error('Неверный ответ базы.'));return;}
        call.resolve({status:m.status,data:m.data});
      }
    };
    window.addEventListener('message',receive);
    frame.addEventListener('load',()=>frame?.contentWindow?.postMessage({channel,type:'hello'},origin));
    frame.src=origin+'/api/bridge';
    document.body.append(frame);
  });
  return ready;
}

export async function api(accessKey:string,payload:Record<string,unknown>){
  await connect();
  const result=await new Promise<{status:number;data:unknown}>((resolve,reject)=>{
    const id=String(++sequence);
    const timer=setTimeout(()=>{pending.delete(id);reject(new TypeError('База не ответила. Повторите попытку.'));},25000);
    pending.set(id,{resolve,reject,timer});
    frame?.contentWindow?.postMessage({channel,type:'request',id,accessKey,payload},origin);
  });
  return {ok:result.status>=200&&result.status<300,status:result.status,json:async()=>result.data};
}
